=== Plugin Name ===
Contributors: MrIonic
Donate link: [Plugin donate link]
Tags: tag1, tag2
Requires at least: 5.0
Tested up to: 5.8
Requires PHP: 7.0
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
