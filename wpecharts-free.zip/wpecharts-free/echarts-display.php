<?php
/*
Plugin Name: WpECharts-Apache ECharts Integration
Plugin URI: [Plugin URI]
Description: This plugin can display charts created with Apache Echarts inside your posts and pages. You can simply use shortcodes to display them.
Version: 1.0.0
Author: MrIonic
Author URI: [Author URI]
License: GPLv2 or later
Text Domain: wpechartsfree
*/

// Enqueue plugin scripts and styles
function echarts_display_enqueue_scripts() {
    wp_enqueue_script( 'echarts', plugin_dir_url( __FILE__ ) . 'assets/js/echarts.js', array(), '5.2.2', true );
}
add_action( 'wp_enqueue_scripts', 'echarts_display_enqueue_scripts' );

// Add an action hook to initialize the admin interface
add_action( 'admin_menu', 'echarts_admin_menu' );

// Function to add the plugin menu page
function echarts_admin_menu() {
    // Add a new menu page under "Settings"
    add_options_page(
        esc_html__( 'WpECharts Settings', 'echarts-free' ),
        esc_html__( 'WpECharts', 'echarts-free' ),
        'manage_options',
        'echarts-free-settings',
        'echarts_display_settings_page'
    );
}

// Function to display the plugin settings page
function echarts_display_settings_page() {
    // Check if the user has sufficient permissions
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }
    ?>
    <div class="wrap">
        <h1><?php echo esc_html__( 'WpECharts', 'echarts-free' ); ?></h1>
        <p><?php echo esc_html__( 'This is the Free version of WpECharts. In free version you can create only one chart. Get our WpECharts Pro plugin to create unlimited charts', 'echarts-free' ); ?></p>
        <h2><a href="https://codecanyon.net/item/wpecharts-apache-echarts-integration-for-wordpress/46227240"><?php echo esc_html__( 'Get Pro Version', 'echarts-free' ); ?></a></h2>
        <p><?php echo esc_html__( 'How to use this plugin?', 'echarts-free' ); ?></p>
        <p><?php echo wp_kses_post( __( '1) Go to <a href="https://echarts.apache.org/examples/en/index.html#chart-type-line">Apache ECharts examples page</a>', 'echarts-free' ) ); ?></p>

        <p><?php echo esc_html__( '2) Select and edit the chart types which allowed by this plugin(See plugin description)', 'echarts-free' ); ?></p>
        <p><?php echo esc_html__( '3) Copy the options code as below', 'echarts-free' ); ?></p>
        <p><?php echo esc_html__( 'option={
  xAxis: {
    type: \'category\',
    data: [\'Mon\', \'Tue\', \'Wed\', \'Thu\', \'Fri\', \'Sat\', \'Sun\']
  },
  yAxis: {
    type: \'value\'
  },
  series: [
    {
      data: [820, 932, 901, 934, 1290, 1330, 1320],
      type: \'line\',
      smooth: true
    }
  ]
};', 'echarts-free' ); ?></p>
        <p><?php echo esc_html__( '4) Paste it in following Chart Options text area', 'echarts-free' ); ?></p>
        <p><?php echo esc_html__( '5) Use this shortcode to display chart inside your posts and pages', 'echarts-free' ); ?></p>
        <p><b>[echarts width="100%" height="600px" ]</b></p>
        <form method="post" action="options.php">
            <?php
            // Output the settings fields
            settings_fields( 'echarts_display_settings' );
            do_settings_sections( 'echarts_display_settings' );
            submit_button();
            ?>
        </form>
    </div>
    <?php
}


// Add an action hook to register the plugin settings
add_action( 'admin_init', 'echarts_register_settings' );

// Function to register the plugin settings
function echarts_register_settings() {
    // Register a new settings section
    add_settings_section(
        'echarts_display_general',
        esc_html__( 'General Settings', 'echarts-free' ),
        'echarts_display_general_section',
        'echarts_display_settings'
    );

    // Register the chart options field
    add_settings_field(
        'echarts_display_chart_options',
        esc_html__( 'Chart Options', 'echarts-free' ),
        'echarts_display_chart_options_field',
        'echarts_display_settings',
        'echarts_display_general'
    );

    // Register the settings
    register_setting(
        'echarts_display_settings',
        'echarts_display_chart_options',
        'sanitize_textarea_field'
    );
}

// Callback function for the general settings section
function echarts_display_general_section() {
    echo '<p>' . esc_html__( 'Configure the settings for WpECharts.', 'echarts-free' ) . '</p>';
}

// Callback function for the chart options field
function echarts_display_chart_options_field() {
    $chart_options = get_option( 'echarts_display_chart_options' );
    echo '<textarea name="echarts_display_chart_options" rows="5" cols="50">' . esc_textarea( $chart_options ) . '</textarea>';
}


// Shortcode to display the chart
function echarts_display_shortcode( $atts ) {
    ob_start(); // Start output buffering

    // Retrieve the shortcode attributes
    $shortcode_atts = shortcode_atts( array(
        'width' => get_option( 'echarts_display_chart_width', '100%' ),
        'height' => get_option( 'echarts_display_chart_height', '400px' ),
        'options' => get_option( 'echarts_display_chart_options', '' ),
    ), $atts );

    // Generate a unique ID for the chart container
    $chart_id = 'chart-container-' . uniqid();
    $chart_options = get_option( 'echarts_display_chart_options' );

    // Output the chart HTML with the specified width and height
    echo '<div id="' . $chart_id . '" style="width: ' . esc_attr( $shortcode_atts['width'] ) . '; height: ' . esc_attr( $shortcode_atts['height'] ) . ';"></div>';
    ?>
    <script>
    // Chart generation logic
    document.addEventListener('DOMContentLoaded', function() {
        // Retrieve the chart container element
        var chartContainer = document.getElementById('<?php echo esc_js( $chart_id ); ?>');

        // Initialize the chart
        var chart = echarts.init(chartContainer);

        
        // Chart configuration options provided by the admin
        var options = <?php echo $chart_options; ?>;


        // Set the chart options and render the chart
        chart.setOption(options);
    });
    </script>
    <?php
    
    return ob_get_clean(); // Return the buffered content
}
add_shortcode( 'echarts', 'echarts_display_shortcode' );
